"""
Lógica de negocio y acceso a datos de la biblioteca personal (KeyDB).

Estructura de datos en KeyDB
----------------------------
libro:<uuid>    -> hash con los campos del libro (titulo, autor, genero,
                   estado, creado, actualizado)
libros:ids      -> set con los UUID de todos los libros (índice para listar)
libros:unicos   -> hash "titulo||autor" normalizado -> uuid
                   (permite detectar duplicados de forma atómica)
"""

import uuid
from datetime import datetime, timezone

import redis

# --------------------------------------------------------------------------
# Constantes del dominio
# --------------------------------------------------------------------------

ESTADOS = ("Pendiente", "Leyendo", "Leído")

# Color de Bootstrap asociado a cada estado (para las etiquetas)
ESTADO_COLORES = {"Pendiente": "secondary", "Leyendo": "warning", "Leído": "success"}

# Opciones del filtro de búsqueda
CAMPOS_BUSQUEDA = {
    "todos": "Título, autor o género",
    "titulo": "Título",
    "autor": "Autor",
    "genero": "Género",
}

# Sugerencias para el campo género (el usuario puede escribir otro)
GENEROS_SUGERIDOS = (
    "Novela", "Ciencia ficción", "Fantasía", "Misterio", "Terror", "Romance",
    "Historia", "Biografía", "Ensayo", "Poesía", "Tecnología", "Autoayuda",
    "Infantil",
)

ETIQUETAS = {"titulo": "título", "autor": "autor", "genero": "género"}
LIMITES = {"titulo": 150, "autor": 100, "genero": 50}

PREFIJO_LIBRO = "libro:"
INDICE_IDS = "libros:ids"
INDICE_UNICOS = "libros:unicos"


# --------------------------------------------------------------------------
# Excepciones propias
# --------------------------------------------------------------------------

class LibroNoEncontradoError(Exception):
    """El libro solicitado no existe en KeyDB."""


class LibroDuplicadoError(Exception):
    """Ya existe un libro con el mismo título y autor."""


# --------------------------------------------------------------------------
# Conexión y validación
# --------------------------------------------------------------------------

def crear_cliente(config):
    """Crea el cliente de KeyDB (redis-py) a partir de la configuración."""
    return redis.Redis(
        host=config.KEYDB_HOST,
        port=config.KEYDB_PORT,
        db=config.KEYDB_DB,
        password=config.KEYDB_PASSWORD,
        decode_responses=True,      # recibir str en lugar de bytes
        socket_connect_timeout=3,   # no quedarse esperando si KeyDB no responde
        socket_timeout=3,
    )


def validar_libro(form):
    """
    Limpia y valida los datos del formulario.

    Devuelve (datos, errores): `datos` es un dict con los valores limpios
    (útil para volver a mostrar el formulario) y `errores` una lista de
    mensajes en español. Si la lista está vacía, los datos son válidos.
    """
    errores = []
    datos = {}

    for campo in ("titulo", "autor", "genero"):
        # " ".join(split()) recorta y colapsa espacios repetidos
        valor = " ".join((form.get(campo) or "").split())
        datos[campo] = valor
        if not valor:
            errores.append(f"El campo {ETIQUETAS[campo]} es obligatorio.")
        elif len(valor) > LIMITES[campo]:
            errores.append(
                f"El campo {ETIQUETAS[campo]} no puede superar "
                f"{LIMITES[campo]} caracteres."
            )

    datos["estado"] = (form.get("estado") or "").strip()
    if datos["estado"] not in ESTADOS:
        errores.append("Seleccione un estado de lectura válido.")

    return datos, errores


def _clave_unica(titulo, autor):
    """Clave normalizada (sin mayúsculas ni espacios extra) para detectar duplicados."""
    norm = lambda s: " ".join(s.split()).casefold()
    return f"{norm(titulo)}||{norm(autor)}"


def _ahora():
    """Fecha/hora actual en UTC (formato ISO)."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# --------------------------------------------------------------------------
# Repositorio
# --------------------------------------------------------------------------

class RepositorioLibros:
    """Operaciones CRUD y búsqueda de libros sobre KeyDB."""

    def __init__(self, cliente):
        self.r = cliente

    # -- Crear -------------------------------------------------------------
    def crear(self, datos):
        """Guarda un libro nuevo y devuelve su id (UUID)."""
        libro_id = str(uuid.uuid4())

        # HSETNX reserva la clave única de forma atómica: devuelve 0 si ya existía
        if not self.r.hsetnx(INDICE_UNICOS, _clave_unica(datos["titulo"], datos["autor"]), libro_id):
            raise LibroDuplicadoError()

        libro = {**datos, "creado": _ahora(), "actualizado": _ahora()}
        try:
            pipe = self.r.pipeline()
            pipe.hset(PREFIJO_LIBRO + libro_id, mapping=libro)
            pipe.sadd(INDICE_IDS, libro_id)
            pipe.execute()
        except redis.RedisError:
            # Si falla el guardado, liberar la reserva para no dejar basura
            self.r.hdel(INDICE_UNICOS, _clave_unica(datos["titulo"], datos["autor"]))
            raise
        return libro_id

    # -- Leer --------------------------------------------------------------
    def obtener(self, libro_id):
        """Devuelve el libro (dict con 'id') o lanza LibroNoEncontradoError."""
        libro = self.r.hgetall(PREFIJO_LIBRO + libro_id)
        if not libro:
            raise LibroNoEncontradoError(libro_id)
        libro["id"] = libro_id
        return libro

    def contar(self):
        """Número total de libros registrados."""
        return self.r.scard(INDICE_IDS)

    def listar(self, consulta="", campo="todos", estado=""):
        """
        Devuelve los libros ordenados por título.

        - consulta: texto a buscar (parcial, sin distinguir mayúsculas)
        - campo: 'titulo', 'autor', 'genero' o 'todos'
        - estado: si se indica, solo libros con ese estado
        """
        ids = list(self.r.smembers(INDICE_IDS))
        if not ids:
            return []

        # Una sola ida y vuelta a KeyDB para traer todos los hashes
        pipe = self.r.pipeline()
        for libro_id in ids:
            pipe.hgetall(PREFIJO_LIBRO + libro_id)
        resultados = pipe.execute()

        consulta = consulta.strip().casefold()
        campos = ("titulo", "autor", "genero") if campo == "todos" else (campo,)

        libros = []
        for libro_id, datos in zip(ids, resultados):
            if not datos:
                continue  # id huérfano en el índice
            if consulta and not any(consulta in datos.get(c, "").casefold() for c in campos):
                continue
            if estado and datos.get("estado") != estado:
                continue
            datos["id"] = libro_id
            libros.append(datos)

        libros.sort(key=lambda l: l["titulo"].casefold())
        return libros

    # -- Actualizar --------------------------------------------------------
    def actualizar(self, libro_id, datos):
        """Actualiza un libro existente (lanza NoEncontrado o Duplicado)."""
        actual = self.obtener(libro_id)

        clave_vieja = _clave_unica(actual["titulo"], actual["autor"])
        clave_nueva = _clave_unica(datos["titulo"], datos["autor"])
        if clave_nueva != clave_vieja:
            # Cambió título o autor: reservar la nueva clave y liberar la anterior
            if not self.r.hsetnx(INDICE_UNICOS, clave_nueva, libro_id):
                raise LibroDuplicadoError()
            self.r.hdel(INDICE_UNICOS, clave_vieja)

        self.r.hset(PREFIJO_LIBRO + libro_id, mapping={**datos, "actualizado": _ahora()})

    # -- Eliminar ----------------------------------------------------------
    def eliminar(self, libro_id):
        """Elimina un libro y sus índices. Devuelve el libro eliminado."""
        libro = self.obtener(libro_id)
        pipe = self.r.pipeline()
        pipe.delete(PREFIJO_LIBRO + libro_id)
        pipe.srem(INDICE_IDS, libro_id)
        pipe.hdel(INDICE_UNICOS, _clave_unica(libro["titulo"], libro["autor"]))
        pipe.execute()
        return libro
