"""
Biblioteca personal - aplicación web con Flask y KeyDB.

Aquí se define la aplicación y sus rutas. La lógica de datos vive en
libros.py, la configuración en config.py y las vistas en /templates.

Ejecución:
    python app.py        (o)        flask --app app run
"""

import hmac
import secrets

import redis
from flask import (
    Flask, abort, flash, redirect, render_template, request, session, url_for,
)

from config import Config
from libros import (
    CAMPOS_BUSQUEDA, ESTADO_COLORES, ESTADOS, GENEROS_SUGERIDOS,
    LibroDuplicadoError, LibroNoEncontradoError, RepositorioLibros,
    crear_cliente, validar_libro,
)

app = Flask(__name__)
app.config.from_object(Config)

# Repositorio que encapsula todas las operaciones sobre KeyDB
repo = RepositorioLibros(crear_cliente(Config))


# --------------------------------------------------------------------------
# Protección CSRF sencilla (token guardado en la sesión firmada)
# --------------------------------------------------------------------------

def _token_csrf():
    """Devuelve el token CSRF de la sesión, creándolo si no existe."""
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


@app.before_request
def proteger_formularios():
    """Rechaza cualquier POST que no traiga el token CSRF correcto."""
    if request.method == "POST":
        enviado = request.form.get("_csrf", "")
        if not hmac.compare_digest(enviado, session.get("_csrf", "")):
            abort(400)


@app.context_processor
def inyectar_en_plantillas():
    """Variables disponibles en todas las plantillas."""
    return {
        "csrf_token": _token_csrf,
        "ESTADOS": ESTADOS,
        "ESTADO_COLORES": ESTADO_COLORES,
        "CAMPOS_BUSQUEDA": CAMPOS_BUSQUEDA,
        "GENEROS_SUGERIDOS": GENEROS_SUGERIDOS,
    }


# --------------------------------------------------------------------------
# Rutas
# --------------------------------------------------------------------------

@app.route("/")
def listar():
    """Listado de libros con búsqueda (por título, autor o género) y filtro de estado."""
    consulta = request.args.get("q", "").strip()
    campo = request.args.get("campo", "todos")
    estado = request.args.get("estado", "")

    # Ignorar valores manipulados en la URL
    if campo not in CAMPOS_BUSQUEDA:
        campo = "todos"
    if estado not in ESTADOS:
        estado = ""

    libros = repo.listar(consulta, campo, estado)
    return render_template(
        "index.html",
        libros=libros,
        total=repo.contar(),
        q=consulta,
        campo=campo,
        estado=estado,
    )


@app.route("/libros/nuevo", methods=["GET", "POST"])
def nuevo():
    """Formulario para agregar un libro."""
    if request.method == "POST":
        datos, errores = validar_libro(request.form)
        if not errores:
            try:
                repo.crear(datos)
            except LibroDuplicadoError:
                errores.append("Ya existe un libro con ese título y autor.")
            else:
                flash(f"Libro «{datos['titulo']}» agregado correctamente.", "success")
                return redirect(url_for("listar"))

        for error in errores:
            flash(error, "danger")
        return render_template("form.html", modo="nuevo", libro=datos), 400

    return render_template("form.html", modo="nuevo", libro={"estado": ESTADOS[0]})


@app.route("/libros/<libro_id>/editar", methods=["GET", "POST"])
def editar(libro_id):
    """Formulario de edición con los datos actuales precargados."""
    try:
        libro = repo.obtener(libro_id)
    except LibroNoEncontradoError:
        flash("El libro que intentas editar no existe.", "warning")
        return redirect(url_for("listar"))

    if request.method == "POST":
        datos, errores = validar_libro(request.form)
        if not errores:
            try:
                repo.actualizar(libro_id, datos)
            except LibroDuplicadoError:
                errores.append("Ya existe otro libro con ese título y autor.")
            except LibroNoEncontradoError:
                flash("El libro ya no existe.", "warning")
                return redirect(url_for("listar"))
            else:
                flash(f"Libro «{datos['titulo']}» actualizado correctamente.", "success")
                return redirect(url_for("listar"))

        for error in errores:
            flash(error, "danger")
        # Conservar lo que el usuario escribió, manteniendo el id
        return render_template("form.html", modo="editar", libro={**libro, **datos}), 400

    return render_template("form.html", modo="editar", libro=libro)


@app.route("/libros/<libro_id>/eliminar", methods=["POST"])
def eliminar(libro_id):
    """Elimina un libro (solo por POST, con confirmación en la interfaz)."""
    try:
        libro = repo.eliminar(libro_id)
    except LibroNoEncontradoError:
        flash("El libro que intentas eliminar no existe.", "warning")
    else:
        flash(f"Libro «{libro['titulo']}» eliminado.", "success")
    return redirect(url_for("listar"))


# --------------------------------------------------------------------------
# Manejo de errores
# --------------------------------------------------------------------------

@app.errorhandler(redis.exceptions.RedisError)
def error_keydb(_error):
    """KeyDB no responde o rechazó la operación."""
    return render_template(
        "error.html",
        codigo=503,
        mensaje="No se pudo conectar con KeyDB. Verifica que el servidor esté "
                "encendido y que los datos de conexión en .env sean correctos.",
    ), 503


@app.errorhandler(400)
def error_400(_error):
    return render_template(
        "error.html", codigo=400,
        mensaje="Solicitud no válida o formulario expirado. Vuelve a intentarlo.",
    ), 400


@app.errorhandler(404)
def error_404(_error):
    return render_template(
        "error.html", codigo=404, mensaje="La página que buscas no existe.",
    ), 404


@app.errorhandler(405)
def error_405(_error):
    return render_template(
        "error.html", codigo=405, mensaje="Método no permitido para esta ruta.",
    ), 405


if __name__ == "__main__":
    app.run(debug=Config.DEBUG)
